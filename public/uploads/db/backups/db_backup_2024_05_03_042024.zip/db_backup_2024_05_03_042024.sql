

-- ==================Table: bimbingans================== 

INSERT INTO `bimbingans` (`bimbingan_id`, `dosen_nip`, `ta_id`, `urutan`, `verfied_by`) VALUES ('1', '198605292019032009', '1', '1', '0');
INSERT INTO `bimbingans` (`bimbingan_id`, `dosen_nip`, `ta_id`, `urutan`, `verfied_by`) VALUES ('2', '198810142019031007', '1', '2', '0');
INSERT INTO `bimbingans` (`bimbingan_id`, `dosen_nip`, `ta_id`, `urutan`, `verfied_by`) VALUES ('3', '32414', '6', '1', '0');
INSERT INTO `bimbingans` (`bimbingan_id`, `dosen_nip`, `ta_id`, `urutan`, `verfied_by`) VALUES ('4', '12312423', '6', '2', '0');
INSERT INTO `bimbingans` (`bimbingan_id`, `dosen_nip`, `ta_id`, `urutan`, `verfied_by`) VALUES ('5', '31313131', '7', '1', '0');
INSERT INTO `bimbingans` (`bimbingan_id`, `dosen_nip`, `ta_id`, `urutan`, `verfied_by`) VALUES ('6', '334220239', '7', '2', '0');


-- ==================Table: bimbingan_log================== 

INSERT INTO `bimbingan_log` (`bimbingan_log_id`, `bimbingan_id`, `bimb_tgl`, `bimb_judul`, `bimb_desc`, `bimb_file`, `bimb_status`, `created_by`, `updated_by`, `verified_by`) VALUES ('8', '1', '2024-04-24', 'hhhhhhhhhhhh', 'hhhhhhhhhhhhhhhhhh', '20240424075351.pdf', '0', '13', '13', '13');
INSERT INTO `bimbingan_log` (`bimbingan_log_id`, `bimbingan_id`, `bimb_tgl`, `bimb_judul`, `bimb_desc`, `bimb_file`, `bimb_status`, `created_by`, `updated_by`, `verified_by`) VALUES ('9', '1', '2024-04-25', 'sssss', 'ssss', '20240425053904.pdf', '0', '13', '13', '13');
INSERT INTO `bimbingan_log` (`bimbingan_log_id`, `bimbingan_id`, `bimb_tgl`, `bimb_judul`, `bimb_desc`, `bimb_file`, `bimb_status`, `created_by`, `updated_by`, `verified_by`) VALUES ('10', '1', '2024-04-25', 'aaaa', 'bbbbbbb', '20240425042830.pdf', '0', '13', '13', '13');
INSERT INTO `bimbingan_log` (`bimbingan_log_id`, `bimbingan_id`, `bimb_tgl`, `bimb_judul`, `bimb_desc`, `bimb_file`, `bimb_status`, `created_by`, `updated_by`, `verified_by`) VALUES ('13', '4', '2024-04-30', 'asdasd', 'aaaa', '20240501101034.pdf', '1', '13', '13', '13');
INSERT INTO `bimbingan_log` (`bimbingan_log_id`, `bimbingan_id`, `bimb_tgl`, `bimb_judul`, `bimb_desc`, `bimb_file`, `bimb_status`, `created_by`, `updated_by`, `verified_by`) VALUES ('16', '3', '2024-04-29', 'ranggaedit', '123', '20240503032119.pdf', '0', '13', '13', '13');
INSERT INTO `bimbingan_log` (`bimbingan_log_id`, `bimbingan_id`, `bimb_tgl`, `bimb_judul`, `bimb_desc`, `bimb_file`, `bimb_status`, `created_by`, `updated_by`, `verified_by`) VALUES ('20', '2', '2024-05-01', 'halo', 'aaa', '20240501061217.pdf', '0', '13', '13', '13');
INSERT INTO `bimbingan_log` (`bimbingan_log_id`, `bimbingan_id`, `bimb_tgl`, `bimb_judul`, `bimb_desc`, `bimb_file`, `bimb_status`, `created_by`, `updated_by`, `verified_by`) VALUES ('23', '5', '2024-05-02', 'Hello World', '345', '20240502104526.pdf', '0', '13', '13', '13');
INSERT INTO `bimbingan_log` (`bimbingan_log_id`, `bimbingan_id`, `bimb_tgl`, `bimb_judul`, `bimb_desc`, `bimb_file`, `bimb_status`, `created_by`, `updated_by`, `verified_by`) VALUES ('26', '1', '2024-05-03', 'aaa', 'aaa', '20240503123321.pdf', '0', '13', '13', '13');
INSERT INTO `bimbingan_log` (`bimbingan_log_id`, `bimbingan_id`, `bimb_tgl`, `bimb_judul`, `bimb_desc`, `bimb_file`, `bimb_status`, `created_by`, `updated_by`, `verified_by`) VALUES ('27', '2', '2024-05-03', 'aaa', 'aaa', '20240503123339.pdf', '0', '13', '13', '13');
INSERT INTO `bimbingan_log` (`bimbingan_log_id`, `bimbingan_id`, `bimb_tgl`, `bimb_judul`, `bimb_desc`, `bimb_file`, `bimb_status`, `created_by`, `updated_by`, `verified_by`) VALUES ('31', '3', '2024-05-03', 'vfvfdaaaa', 'xsscs', '20240503031918.pdf', '0', '1', '1', '1');
INSERT INTO `bimbingan_log` (`bimbingan_log_id`, `bimbingan_id`, `bimb_tgl`, `bimb_judul`, `bimb_desc`, `bimb_file`, `bimb_status`, `created_by`, `updated_by`, `verified_by`) VALUES ('32', '6', '2024-05-03', 'jduulku', 'apik banget', '20240503035626.pdf', '1', '1', '1', '1');


-- ==================Table: dokumen_syarat_ta================== 

INSERT INTO `dokumen_syarat_ta` (`dokumen_id`, `dokumen_syarat`, `dokumen_file`, `created_by`, `verified_by`) VALUES ('1', 'Surat Keterangan PKL', '', '', '');
INSERT INTO `dokumen_syarat_ta` (`dokumen_id`, `dokumen_syarat`, `dokumen_file`, `created_by`, `verified_by`) VALUES ('2', 'Surat Keterangan KKL', '', '', '');


-- ==================Table: dosens================== 

INSERT INTO `dosens` (`dosen_nip`, `dosen_nama`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES ('12312423', 'Penguji Aoki', '', '2024-04-25 20:59:17', '', '2024-04-25 20:59:17');
INSERT INTO `dosens` (`dosen_nip`, `dosen_nama`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES ('198605292019032009', 'Aisyatul Karima', '', '2024-04-05 10:00:57', '', '2024-04-05 10:00:57');
INSERT INTO `dosens` (`dosen_nip`, `dosen_nama`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES ('198810142019031007', 'Amran Yobioktabera', '', '2024-04-05 10:00:57', '', '2024-04-05 10:00:57');
INSERT INTO `dosens` (`dosen_nip`, `dosen_nama`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES ('31313131', 'Sekre', '', '2024-04-25 20:59:45', '', '2024-04-25 20:59:45');
INSERT INTO `dosens` (`dosen_nip`, `dosen_nama`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES ('32414', 'Penguji Satu', '', '2024-04-25 20:59:17', '', '2024-04-25 20:59:17');
INSERT INTO `dosens` (`dosen_nip`, `dosen_nama`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES ('334220239', 'Penguji Dua', '', '2024-04-25 20:59:45', '', '2024-04-25 20:59:45');


-- ==================Table: mahasiswas================== 

INSERT INTO `mahasiswas` (`mhs_nim`, `nama_id`, `kelas`, `email`, `thn_ajaran`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES ('3.34.22.0.03', 'Aoki Takeshi', 'IK-3A', 'awoka@gmail.com', '2222-3333', '', '2024-05-01 09:21:53', '', '2024-04-29 15:26:47');
INSERT INTO `mahasiswas` (`mhs_nim`, `nama_id`, `kelas`, `email`, `thn_ajaran`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES ('3.34.22.0.19', 'Rangga Aldian', 'IK-4A', 'ranggo@gmail.com', '2020-2024', '', '2024-05-02 07:01:39', '', '2024-05-02 07:01:26');
INSERT INTO `mahasiswas` (`mhs_nim`, `nama_id`, `kelas`, `email`, `thn_ajaran`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES ('3.34.22.0.24', 'Zalfa Rosya', 'TI-3A', 'zalfarosya@gmail.com', '2022/2025', '', '2024-05-01 09:22:02', '', '2024-04-05 09:56:26');


-- ==================Table: menus================== 

INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('1', 'Menu Manajemen', '#', '', '', '0', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('2', 'Dashboard', 'home', 'fas fa-home', '', '1', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('3', 'Manajemen Pengguna', '#', 'fas fa-users-cog', '', '1', '2');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('4', 'Kelola Pengguna', 'manage-user', '', '', '3', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('5', 'Kelola Role', 'manage-role', '', '', '3', '2');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('6', 'Kelola Menu', 'manage-menu', '', '', '3', '3');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('7', 'Backup Server', '#', '', '', '0', '2');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('8', 'Backup Database', 'dbbackup', 'fas fa-database', '', '7', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('9', 'Dashboard Mahasiswa', '#', 'fas fa-home', '', '0', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('10', 'Dashboard Mahasiswa', 'dashboard-mahasiswa', 'fas fa-home', '', '9', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('12', 'Bimbingan', '#', '', '', '0', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('13', 'Pembimbingan', 'bimbingan-mahasiswa', 'fas fa-chalkboard-teacher', '', '12', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('15', 'Tugas Akhir', '#', '', '', '0', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('16', 'Daftar Tugas Akhir', 'daftar-tugas-akhir', 'fas fa-graduation-cap', '', '15', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('18', 'Sidang Tugas Akhir', 'sidang-tugas-akhir', 'fas fa-graduation-cap', '', '15', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('19', 'Menu Manajemen', '#', '', '', '0', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('20', 'Dashboard', 'home', 'fas fa-home', '', '19', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('21', 'Manajemen Pengguna', '#', 'fas fa-users-cog', '', '19', '2');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('22', 'Kelola Pengguna', 'manage-user', '', '', '21', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('23', 'Menu Manajemen', '#', '', '', '0', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('24', 'Dashboard', 'home', 'fas fa-home', '', '23', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('25', 'Manajemen Pengguna', '#', 'fas fa-users-cog', '', '23', '2');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('26', 'Kelola Pengguna', 'manage-user', '', '', '25', '1');


-- ==================Table: migrations================== 

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('1', '2014_10_12_000000_create_users_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('2', '2014_10_12_100000_create_password_resets_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('3', '2019_08_19_000000_create_failed_jobs_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('4', '2019_12_14_000001_create_personal_access_tokens_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('5', '2024_01_01_234158_create_menus_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('6', '2024_02_02_053619_create_permission_tables', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('7', '2024_02_03_232722_create_role_has_menus_tables', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('8', '2024_02_03_235312_add_menu_id_on_permission', '1');


-- ==================Table: model_has_roles================== 

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES ('1', 'App\\Models\\User', '1');
INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES ('2', 'App\\Models\\User', '4');
INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES ('2', 'App\\Models\\User', '7');
INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES ('2', 'App\\Models\\User', '8');


-- ==================Table: permissions================== 

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('1', 'create_user', 'web', '2024-03-25 13:11:25', '2024-03-25 13:11:25', '4');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('2', 'read_user', 'web', '2024-03-25 13:11:25', '2024-03-25 13:11:25', '4');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('3', 'update_user', 'web', '2024-03-25 13:11:25', '2024-03-25 13:11:25', '4');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('4', 'delete_user', 'web', '2024-03-25 13:11:26', '2024-03-25 13:11:26', '4');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('5', 'create_role', 'web', '2024-03-25 13:11:26', '2024-03-25 13:11:26', '5');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('6', 'read_role', 'web', '2024-03-25 13:11:26', '2024-03-25 13:11:26', '5');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('7', 'update_role', 'web', '2024-03-25 13:11:26', '2024-03-25 13:11:26', '5');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('8', 'delete_role', 'web', '2024-03-25 13:11:26', '2024-03-25 13:11:26', '5');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('9', 'create_menu', 'web', '2024-03-25 13:11:26', '2024-03-25 13:11:26', '6');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('10', 'read_menu', 'web', '2024-03-25 13:11:26', '2024-03-25 13:11:26', '6');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('11', 'update_menu', 'web', '2024-03-25 13:11:26', '2024-03-25 13:11:26', '6');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('12', 'delete_menu', 'web', '2024-03-25 13:11:26', '2024-03-25 13:11:26', '6');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('13', 'backup_database', 'web', '2024-03-25 13:11:26', '2024-03-25 13:11:26', '8');


-- ==================Table: roles================== 

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES ('1', 'superadmin', 'web', '2024-03-25 13:11:28', '2024-03-25 13:11:28');
INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES ('2', 'mahasiswa', 'web', '2024-03-28 13:24:10', '2024-03-28 13:24:10');
INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES ('3', 'dosen', 'web', '2024-03-28 13:45:37', '2024-03-28 13:45:37');


-- ==================Table: role_has_menus================== 

INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('163', '9', '2');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('164', '10', '2');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('165', '12', '2');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('166', '13', '2');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('168', '15', '2');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('169', '16', '2');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('170', '18', '2');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('171', '1', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('172', '2', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('173', '3', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('174', '4', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('175', '5', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('176', '6', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('177', '7', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('178', '8', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('179', '9', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('180', '10', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('181', '12', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('182', '13', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('184', '15', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('185', '16', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('186', '18', '1');


-- ==================Table: role_has_permissions================== 

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('1', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('2', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('3', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('4', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('5', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('6', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('7', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('8', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('9', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('10', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('11', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('12', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('13', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('13', '3');


-- ==================Table: tas================== 

INSERT INTO `tas` (`ta_id`, `mhs_nim`, `ta_judul`, `created_by`, `created_at`, `verfied_by`) VALUES ('1', '3.34.22.0.24', 'Halo Ocha', '', '2024-04-05 09:56:45', '0');
INSERT INTO `tas` (`ta_id`, `mhs_nim`, `ta_judul`, `created_by`, `created_at`, `verfied_by`) VALUES ('6', '3.34.22.0.03', 'oi', '13', '2024-04-29 15:30:15', '13');
INSERT INTO `tas` (`ta_id`, `mhs_nim`, `ta_judul`, `created_by`, `created_at`, `verfied_by`) VALUES ('7', '3.34.22.0.19', 'Judul Rangga', '13', '2024-05-02 22:00:07', '13');


-- ==================Table: unsur_nilai_penguji================== 

INSERT INTO `unsur_nilai_penguji` (`nilai_id`, `unsur_nilai`, `bobot`) VALUES ('1', 'Isi dan Bobot Naskah', '0.15');


-- ==================Table: users================== 

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES ('1', 'Super Admin', 'superadmin@gmail.com', '2024-04-04 12:47:13', '$2y$10$5/g4mviSdlyiY1XXw/3.Uu6fDi9q0isWmjbea75.LgYYEK8nLPNWi', '7sEk5xNn8FrksQB3VWOrWytR6J6PP6KqYcJFKA7ko3r95ikvgrZDx5Xyr5z9', '2024-03-25 13:11:28', '2024-04-04 12:47:13');
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES ('4', 'Zalfa', 'zalfarosya@gmail.com', '2024-04-04 22:18:54', '$2y$10$IwYD9Hgj.OBam/lExo7F6u3LwlEMqnoTinh6kXJTAJrvOchGeBu7y', '', '2024-04-01 14:55:16', '2024-04-04 22:18:54');
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES ('7', 'Aoki', 'awoka@gmail.com', '2024-04-29 15:24:25', '$2y$10$gOHMj1S4kkF4TmjI0CMFe.Kom0ZGu0XVO63g/BRmfVjKqL/9PQ4dC', '', '2024-04-29 15:24:25', '2024-04-29 15:24:25');
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES ('8', 'Rangga', 'ranggo@gmail.com', '2024-05-03 03:59:56', '$2y$10$ZLVnXFe5jBbY1uSyWkBmMuIUGrjZ2PGcSDxProt3/DcpHXamhvwBe', '', '2024-05-02 06:56:49', '2024-05-03 03:59:56');
